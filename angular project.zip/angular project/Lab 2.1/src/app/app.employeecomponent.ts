import {Component} from '@angular/core';
import { Employee } from './app.employee';

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html'
})
export class AppEmployeeComponent{
    
    status: number;
    employees: Employee[] = [
    {empId: 1001, empName: "Rahul", empSalary: 9000, empDepartment: "Java"},
    {empId: 1002, empName: "Sachin", empSalary: 19000, empDepartment: "OraApps"},
    {empId: 1003, empName: "Vikash", empSalary: 29000, empDepartment: "BI"}
    ];
    
    empId: number;
    empName: string;
    empSalary: number;
    empDepartment: string;

    id: number;
    name: string;
    sal: number;
    dept: string;
    count: number;

    submit(): void{
        this.status = 1;
        this.employees.push(new Employee(this.empId, this.empName, this.empSalary, this.empDepartment));
    }
    
    update(empIndex: number): void{
        this.id = this.employees[empIndex].empId;
        this.name = this.employees[empIndex].empName;
        this.sal = this.employees[empIndex].empSalary;
        this.dept = this.employees[empIndex].empDepartment;
        this.count = empIndex;
        
    }
    
    updateEmp(): void{
        this.status = 2;
        this.employees[this.count].empId = this.id;
        this.employees[this.count].empName = this.name;
        this.employees[this.count].empSalary = this.sal;
        this.employees[this.count].empDepartment = this.dept;
    }
    
    delete(empIndex: number): void{
        this.status = 3;
        this.employees.splice(empIndex, 1);
    }
}