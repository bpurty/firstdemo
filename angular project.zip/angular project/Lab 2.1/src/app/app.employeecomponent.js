"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var app_employee_1 = require("./app.employee");
var AppEmployeeComponent = (function () {
    function AppEmployeeComponent() {
        this.employees = [
            { empId: 1001, empName: "Rahul", empSalary: 9000, empDepartment: "Java" },
            { empId: 1002, empName: "Sachin", empSalary: 19000, empDepartment: "OraApps" },
            { empId: 1003, empName: "Vikash", empSalary: 29000, empDepartment: "BI" }
        ];
    }
    AppEmployeeComponent.prototype.submit = function () {
        this.status = 1;
        this.employees.push(new app_employee_1.Employee(this.empId, this.empName, this.empSalary, this.empDepartment));
    };
    AppEmployeeComponent.prototype.update = function (empIndex) {
        this.id = this.employees[empIndex].empId;
        this.name = this.employees[empIndex].empName;
        this.sal = this.employees[empIndex].empSalary;
        this.dept = this.employees[empIndex].empDepartment;
        this.count = empIndex;
    };
    AppEmployeeComponent.prototype.updateEmp = function () {
        this.status = 2;
        this.employees[this.count].empId = this.id;
        this.employees[this.count].empName = this.name;
        this.employees[this.count].empSalary = this.sal;
        this.employees[this.count].empDepartment = this.dept;
    };
    AppEmployeeComponent.prototype.delete = function (empIndex) {
        this.status = 3;
        this.employees.splice(empIndex, 1);
    };
    return AppEmployeeComponent;
}());
AppEmployeeComponent = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.employeecomponent.html'
    })
], AppEmployeeComponent);
exports.AppEmployeeComponent = AppEmployeeComponent;
