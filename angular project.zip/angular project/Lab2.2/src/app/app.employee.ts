export class Employee {
    empId: number;
    empName: string;
    empSalary: number;
    empDepartment: string;
    empJoiningDate: string;

    constructor(id: number, name: string, salary: number, dept: string, date: string){
        this.empId = id;
        this.empName = name;
        this.empSalary = salary;
        this.empDepartment = dept;
        this.empJoiningDate = date;
    }

}