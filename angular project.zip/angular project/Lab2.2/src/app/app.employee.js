"use strict";
var Employee = (function () {
    function Employee(id, name, salary, dept, date) {
        this.empId = id;
        this.empName = name;
        this.empSalary = salary;
        this.empDepartment = dept;
        this.empJoiningDate = date;
    }
    return Employee;
}());
exports.Employee = Employee;
