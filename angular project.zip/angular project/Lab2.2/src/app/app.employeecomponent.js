"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppEmployeeComponent = (function () {
    function AppEmployeeComponent() {
        this.employees = [
            { empId: 1001, empName: "Rahul", empSalary: 9000, empDepartment: "JAVA", empJoiningDate: '6/12/2014' },
            { empId: 1002, empName: "Vikash", empSalary: 11000, empDepartment: "ORAAPS", empJoiningDate: '6/12/2017' },
            { empId: 1003, empName: "Uma", empSalary: 12000, empDepartment: "JAVA", empJoiningDate: '6/12/2010' },
            { empId: 1004, empName: "Sachin", empSalary: 11500, empDepartment: "ORAAPS", empJoiningDate: '11/12/2017' },
            { empId: 1005, empName: "Amol", empSalary: 7000, empDepartment: ".NET", empJoiningDate: '1/1/2018' },
            { empId: 1006, empName: 'Vishal', empSalary: 17000, empDepartment: 'BI', empJoiningDate: '9/12/2012' },
            { empId: 1007, empName: 'Rajita', empSalary: 21000, empDepartment: 'BI', empJoiningDate: '6/7/2014' },
            { empId: 1008, empName: 'Neelima', empSalary: 81000, empDepartment: 'TESTING', empJoiningDate: '6/17/2015' },
            { empId: 1009, empName: 'Daya', empSalary: 1000, empDepartment: 'TESTING', empJoiningDate: '6/17/2016' }
        ];
    }
    AppEmployeeComponent.prototype.sortId = function () {
        this.employees.sort(function (emp1, emp2) {
            if (emp1.empId < emp2.empId)
                return -1;
            else if (emp1.empId > emp2.empId)
                return 1;
            else
                return 0;
        });
    };
    AppEmployeeComponent.prototype.sortName = function () {
        this.employees.sort(function (emp1, emp2) {
            if (emp1.empName < emp2.empName)
                return -1;
            else if (emp1.empName > emp2.empName)
                return 1;
            else
                return 0;
        });
    };
    AppEmployeeComponent.prototype.sortSalary = function () {
        this.employees.sort(function (emp1, emp2) {
            if (emp1.empSalary < emp2.empSalary)
                return -1;
            else if (emp1.empSalary > emp2.empSalary)
                return 1;
            else
                return 0;
        });
    };
    AppEmployeeComponent.prototype.sortDept = function () {
        this.employees.sort(function (emp1, emp2) {
            if (emp1.empDepartment < emp2.empDepartment)
                return -1;
            else if (emp1.empDepartment > emp2.empDepartment)
                return 1;
            else
                return 0;
        });
    };
    return AppEmployeeComponent;
}());
AppEmployeeComponent = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.employeecomponent.html'
    })
], AppEmployeeComponent);
exports.AppEmployeeComponent = AppEmployeeComponent;
