import {Component} from '@angular/core';
import { Employee } from './app.employee';

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html'
})
export class AppEmployeeComponent{
    
   
    employees: Employee[] = [
    {empId: 1001, empName: "Rahul", empSalary: 9000, empDepartment: "JAVA", empJoiningDate: '6/12/2014'},
    {empId: 1002, empName: "Vikash", empSalary: 11000, empDepartment: "ORAAPS", empJoiningDate: '6/12/2017'},
    {empId: 1003, empName: "Uma", empSalary: 12000, empDepartment: "JAVA", empJoiningDate: '6/12/2010'},
    {empId: 1004, empName: "Sachin", empSalary:11500, empDepartment: "ORAAPS", empJoiningDate: '11/12/2017'},
    {empId: 1005, empName: "Amol", empSalary: 7000, empDepartment: ".NET", empJoiningDate: '1/1/2018'},
    {empId: 1006, empName:'Vishal', empSalary:17000, empDepartment:'BI',empJoiningDate:'9/12/2012'},
    {empId: 1007, empName:'Rajita', empSalary:21000, empDepartment:'BI',empJoiningDate:'6/7/2014'},
    {empId: 1008, empName:'Neelima', empSalary:81000, empDepartment:'TESTING',empJoiningDate:'6/17/2015'},
    {empId: 1009, empName:'Daya', empSalary:1000, empDepartment:'TESTING',empJoiningDate:'6/17/2016'}

    ];

    sortId(): void{
        this.employees.sort( function(emp1: Employee, emp2: Employee){
            if(emp1.empId < emp2.empId)
                return -1;
            else if(emp1.empId > emp2.empId)
                   return 1;
            else
                return 0;
        });
    }
    
    sortName(): void{
        this.employees.sort( function(emp1: Employee, emp2: Employee){
            if(emp1.empName < emp2.empName)
                return -1;
            else if(emp1.empName > emp2.empName)
                   return 1;
            else
                return 0;
        });
    }
    
    sortSalary(): void{
        this.employees.sort( function(emp1: Employee, emp2: Employee){
            if(emp1.empSalary < emp2.empSalary)
                return -1;
            else if(emp1.empSalary > emp2.empSalary)
                   return 1;
            else
                return 0;
        });
    }
    
    sortDept(): void{
        this.employees.sort( function(emp1: Employee, emp2: Employee){
            if(emp1.empDepartment < emp2.empDepartment)
                return -1;
            else if(emp1.empDepartment > emp2.empDepartment)
                   return 1;
            else
                return 0;
        });
    }
}