package com.capg.uas.exception;

public class UASException extends Exception{

	private static final long serialVersionUID = 1L;

	public UASException(String errMsg){
		super(errMsg);
	}

}
