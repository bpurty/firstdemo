export class Product {
    id: number;
    name: string;
    cost: number;
    type: boolean; // online or offline
    category: string;
    store: string[]; // available in store

}