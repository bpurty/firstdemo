import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule }  from '@angular/forms';
import { ProductComponent } from  './app.productform';


@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent, ProductComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
