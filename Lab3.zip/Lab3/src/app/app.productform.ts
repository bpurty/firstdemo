import { Component } from '@angular/core';
import { NgForm } from "@angular/Forms/forms";
import { Product } from './product';
import { Category } from './category';

@Component( {
    selector: 'prod-component',
    templateUrl: './app.productform.html'
} )

export class ProductComponent {
    
    //store: boolean[] = [false, false, false, false];
    prod: Product = { id: null, name: null, cost: null, type: null, category: null,
            store: new Array(null, null, null, null)};
    categories: Category[] = [
                              {id: 1, name: "Grocery"},
                              {id: 2, name: "Mobile"},
                              {id: 3, name: "Electronics "},
                              {id: 4, name: "Cloths"},
                              ];

    onSubmit(): void {
        console.log(this.prod);
    }
    getData(prodForm: NgForm): void {
        console.log(prodForm.value);
    }
}
