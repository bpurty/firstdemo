package com.capgemini.uas.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IMacService;

@Controller
public class MacController {
	
	@Autowired
	private IMacService macService;
	
	
	
	@RequestMapping("/macLogin")
	public String macLogin(Model model){
		model.addAttribute("userObj",new UsersBean());
		return "/jsp/login";
		
	}
	
	
	@RequestMapping("/validateLogin")
	public String validateLogin(@ModelAttribute("userObj") @Valid UsersBean user,@RequestParam("uname")String loginId,@RequestParam("upass")String password,BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "/jsp/login";
		}

		UsersBean userInfo;
		user=new UsersBean(loginId,password,null);
		model.addAttribute("userObj",user);
		try {
			userInfo = macService.isValidUserLogin(user);
			if (userInfo != null) {
				if (userInfo.getRole().equalsIgnoreCase("mac")) {
					return "/jsp/macViewList";
				} else if (userInfo.getRole().equalsIgnoreCase("admin")) {
					return "AdminHome";
				}
			} else {
				return "/jsp/login";
			}
		} catch (UASException exception) {
			//logger.info(e.getMessage());
			String errObj = exception.getMessage();
			model.addAttribute("errObj", errObj);
			return "/jsp/dataerror";
		}
		
		return "/jsp/login";
	}
	
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception e) {
		//send email to control center
		ModelAndView mav=new ModelAndView();
		mav.addObject("err",e);
		mav.setViewName("dataerror");
		System.out.println(e.getMessage());
		return mav;
	}
}
