package com.capgemini.uas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.dao.IMacDao;
import com.capgemini.uas.exception.UASException;

@Service("macService")
public class MacServiceImpl implements IMacService {

	@Autowired
	private IMacDao macDao;

	@Override
	public UsersBean isValidUserLogin(UsersBean user) throws UASException {
		return macDao.isValidUserLogin(user);
	}
	

}
