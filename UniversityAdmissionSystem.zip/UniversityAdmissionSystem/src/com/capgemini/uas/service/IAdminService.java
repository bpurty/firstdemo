package com.capgemini.uas.service;

import com.capgemini.uas.exception.UASException;

public interface IAdminService {
	
}
