package com.capgemini.uas.dao;

import java.util.List;

import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;

public interface IApplicantDao {
	
	List<ProgramScheduledBean> getAllPrograms() throws UASException;
	String getStatusbyId(int appId) throws UASException;
	
}
