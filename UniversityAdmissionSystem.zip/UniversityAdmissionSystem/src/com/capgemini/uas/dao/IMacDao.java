package com.capgemini.uas.dao;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;


public interface IMacDao {

	UsersBean isValidUserLogin(UsersBean user) throws UASException;

}
