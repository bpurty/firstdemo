"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var flight_service_1 = require("./flight.service");
var FlightList = (function () {
    function FlightList(flightService) {
        this.flightService = flightService;
        this.update = false;
        this.path = ['Flight'];
        this.order = 1;
        this.flight = {};
        this.search = '';
        this.index = 0;
    }
    FlightList.prototype.changeIndexToOne = function () {
        this.index = 1;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToTwo = function () {
        this.index = 2;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToThree = function () {
        this.index = 3;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFour = function () {
        this.index = 4;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFive = function () {
        this.index = 5;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToSix = function () {
        this.index = 6;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.ngOnInit = function () {
        var _this = this;
        console.log("ng-init called...");
        this.flightService.getAllFlights().subscribe(function (flightData) { return _this.flights = flightData; });
    };
    FlightList.prototype.deleteIt = function (flight1) {
        var index = this.flights.indexOf(flight1, 0);
        console.log(index);
        this.flights.splice(index, 1);
    };
    FlightList.prototype.sortTable = function (prop) {
        this.path = prop.split('.');
        this.order = this.order * 1; // change order
        return false; // do not reload
    };
    FlightList.prototype.updateFlight = function (flight2) {
        this.update = true;
        var index = this.flights.indexOf(flight2, 0);
        this.count = index;
        this.fid = this.flights[index].id;
        this.flightname = this.flights[index].fname;
        this.fdepartureTime = this.flights[index].departureTime;
        this.farrivalTime = this.flights[index].arrivalTime;
        this.fstatus = this.flights[index].status;
        this.fcost = this.flights[index].cost;
    };
    FlightList.prototype.onUpdate = function () {
        this.update = false;
        this.flights[this.count].id = this.fid;
        this.flights[this.count].fname = this.flightname;
        this.flights[this.count].departureTime = this.fdepartureTime;
        this.flights[this.count].arrivalTime = this.farrivalTime;
        this.flights[this.count].status = this.fstatus;
        this.flights[this.count].cost = this.fcost;
    };
    FlightList.prototype.addFlight = function () {
        this.clear();
        this.add = true;
    };
    FlightList.prototype.clear = function () {
        this.fid = 0;
        this.flightname = null;
        this.fdepartureTime = null;
        this.farrivalTime = null;
        this.fstatus = null;
        this.fcost = 0;
    };
    FlightList.prototype.addFlightData = function () {
        var flightData = this.flightObject();
        /* this.flights.push(flightData);*/
        this.flights.push(Object.assign({}, flightData));
        console.log(this.flights);
        this.add = false;
    };
    FlightList.prototype.flightObject = function () {
        this.flight.id = this.fid;
        this.flight.fname = this.flightname;
        this.flight.departureTime = this.fdepartureTime;
        this.flight.arrivalTime = this.farrivalTime;
        this.flight.status = this.fstatus;
        this.flight.cost = this.fcost;
        return this.flight;
    };
    return FlightList;
}());
FlightList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.flightcomponent.html',
        providers: [flight_service_1.FlightService]
    }),
    __metadata("design:paramtypes", [flight_service_1.FlightService])
], FlightList);
exports.FlightList = FlightList;
