import { Component, OnInit } from '@angular/core';
import { IFlight } from './flight';
import { FlightService } from './flight.service';

@Component({
    selector: '<my-component></my-component>',
    templateUrl: './app.flightcomponent.html',
    providers: [FlightService]
})

export class FlightList implements OnInit {
    count: number;
add: boolean;
    update: boolean=false;
    path: string[] = ['Flight'];
   order: number = 1;
    flights: IFlight[];
     flight: any={};
    search: string = '';
    index: number = 0;

fid: number;
flightname: string;
fdepartureTime: string;
farrivalTime:string;
fstatus:string;
fcost: number;

    changeIndexToOne(): void {
        this.index = 1;
        console.log("index changed to: " + this.index);
    }
    changeIndexToTwo(): void {
        this.index = 2;
        console.log("index changed to: " + this.index);
    }
    changeIndexToThree(): void {
        this.index = 3;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFour(): void {
        this.index = 4;
        console.log("index changed to: " + this.index);
    }
    
    changeIndexToFive(): void {
        this.index = 5;
        console.log("index changed to: " + this.index);
    }
    
    changeIndexToSix(): void {
        this.index = 6;
        console.log("index changed to: " + this.index);
    }
    
    constructor(private flightService: FlightService) {
        
    }
    
    ngOnInit(): void {
        console.log("ng-init called...");
        this.flightService.getAllFlights().subscribe((flightData) => this.flights = flightData);
    }
    
    deleteIt(flight1:IFlight):void{
        let index=this.flights.indexOf(flight1,0);
        console.log(index);
        this.flights.splice(index, 1);
        
    }
    sortTable( prop: string ) {
        this.path = prop.split( '.' )
        this.order = this.order * 1 ; // change order
        return false; // do not reload
    }
    
    updateFlight(flight2:IFlight):void{
        this.update=true;
        let index=this.flights.indexOf(flight2,0);
        this.count=index;
        this.fid=this.flights[index].id;
        this.flightname=this.flights[index].fname;
        this.fdepartureTime=this.flights[index].departureTime;
        this.farrivalTime=this.flights[index].arrivalTime;
        this.fstatus=this.flights[index].status;
        this.fcost=this.flights[index].cost;
    }
   
    
        onUpdate():void{
            this.update=false;
            this.flights[this.count].id=  this.fid;
            this.flights[this.count].fname=this.flightname;
            this.flights[this.count].departureTime=this.fdepartureTime;
            this.flights[this.count].arrivalTime= this.farrivalTime;
            this.flights[this.count].status=this.fstatus;
            this.flights[this.count].cost= this.fcost;
           
        }
    
        addFlight():void{
            this.clear();
            this.add=true;
            
            
        }
        clear():void{
            this.fid=0;
            this.flightname=null;
            this.fdepartureTime=null;
            this.farrivalTime=null;
            this.fstatus=null;
            this.fcost=0;
        }
        addFlightData():void{
            let flightData=this.flightObject();
           /* this.flights.push(flightData);*/
            this.flights.push(Object.assign({}, flightData));
            console.log(this.flights);
            this.add=false;
        }
        flightObject():IFlight{
            this.flight.id=this.fid;
            this.flight.fname=this.flightname;
            this.flight.departureTime=this.fdepartureTime;
            this.flight.arrivalTime= this.farrivalTime;
            this.flight.status=this.fstatus;
            this.flight.cost= this.fcost;
            return this.flight;
             
         }
    

}