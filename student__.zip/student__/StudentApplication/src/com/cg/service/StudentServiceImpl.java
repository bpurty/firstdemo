package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IStudentDAO;
import com.cg.entities.Student;
import com.cg.exception.StudentException;

@Service
@Transactional
public class StudentServiceImpl implements IStudentService {

	@Autowired
	IStudentDAO questionDao;
	
	@Override
	public int addStudent(Student question) throws StudentException {
		
		
		return questionDao.addStudent(question);
	}

	

}
