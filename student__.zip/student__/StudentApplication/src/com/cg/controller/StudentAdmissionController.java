package com.cg.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.Student;
import com.cg.exception.StudentException;
import com.cg.service.IStudentService;

@Controller
public class StudentAdmissionController {

	@Autowired
	IStudentService studentService;
	
	@RequestMapping("index")
	public String check()
	{
		return "index";
	}
	@RequestMapping("student")
	public String addQuestion(Model model)
	{
		Student student = new Student();
		
		model.addAttribute("student",student);
		model.addAttribute("branch",new String[]{"CS","MECHANICAL","CIVIL"});
		
		return "student";
	}
	@RequestMapping("add")
 	public String addition(@Valid @ModelAttribute("student") Student student,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			return "student";
		}
		if( student.getOptionalSubject() ==0 )
		{
			 throw new StudentException(" Optional subject  Cannot be  zero ");
		}
		
	    int studentId=studentService.addStudent(student);
	    model.addAttribute("studentId",studentId);
		
		return "student";
	}
}
