package com.cg.dao;

import com.cg.entities.Student;
import com.cg.exception.StudentException;

public interface IStudentDAO {

	public int addStudent(Student question) throws StudentException;
	
}
