package com.cg.staticDB;

import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Flight;



public class FlightDb {

private static List<Flight> fList=new ArrayList<Flight>();
	
	static{
		
		fList.add(new Flight(1,"Air Asia","05:00 am","04:00 am","On Time",8700));
		fList.add(new Flight(2,"Air India","07:00 am","05:00 am","On Time",8000));
		fList.add(new Flight(3,"Go Air","10:00 am","09:00 am","Delay",5000));
		fList.add(new Flight(4,"Jet Airways","13:00 pm","12:00 am","On Time",8800));
		fList.add(new Flight(5,"Indigo","18:00 pm","17:00 pm","Delay",3500));
	}

	public static List<Flight> getFlightList() {
		return fList;
	}

	
}
