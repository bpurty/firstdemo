package com.cg.service;

import java.util.List;

import org.springframework.ui.Model;

import com.cg.beans.Flight;

public interface IFlightService {

	List<Flight> getAllFlight();

	void deleteFlight(int id);

	void addFlight(Flight flight);

	Flight searchFlight(int id);

	void updateFlight(Flight flight);

}
