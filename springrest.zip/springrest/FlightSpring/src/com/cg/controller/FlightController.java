package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Flight;
import com.cg.service.IFlightService;

@RestController
public class FlightController {

	@Autowired
	private IFlightService fservive;

	@RequestMapping(value = "/flight", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Flight> getAllFlight(Model model) {
		return fservive.getAllFlight();

	}

	@RequestMapping(value = "/flight/delete/{id}", headers = "Accept=application/json", method = RequestMethod.DELETE)
	public List<Flight> deleteFlight(@PathVariable("id") int id) {
		fservive.deleteFlight(id);
		return fservive.getAllFlight();
	}

	@RequestMapping(value = "/flight/create/", consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json", method = RequestMethod.POST)
	public List<Flight> createFlight(@RequestBody Flight flight) {
		fservive.addFlight(flight);
		return fservive.getAllFlight();
	}
	@RequestMapping(value="/flight/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public Flight searchFlight(@PathVariable("id") int id){
		
		return fservive.searchFlight(id);
		
	}
	@RequestMapping(value="/flight/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<Flight> updateFlight(@RequestBody Flight flight){
		fservive.updateFlight(flight);
		return fservive.getAllFlight();
		
	}
}
