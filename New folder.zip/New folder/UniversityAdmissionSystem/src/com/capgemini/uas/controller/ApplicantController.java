package com.capgemini.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IApplicantService;


@Controller
public class ApplicantController {
	
	@Autowired
	private IApplicantService applicantService;
	
	@RequestMapping("/applicant")
	public String showApplicantHome() {
		System.out.println("show applicant home");
		return "jsp/applicantHome";
	}
	
	@RequestMapping("/applicantview")
	public String showApplicantView(Model model) throws UASException {
		System.out.println("show applicant view and apply");
		List<ProgramScheduledBean> progList = applicantService.getAllPrograms();
		model.addAttribute("progList", progList);
		//System.out.println("heyyyy");
		return "jsp/applicantView";
	}

/*	
	@ExceptionHandler(Exception.class)
	public String handleError(Exception e) {
		//send email to control center
		System.out.println(e.getMessage());
		return "jsp/dataerror";
				
	}*/
}