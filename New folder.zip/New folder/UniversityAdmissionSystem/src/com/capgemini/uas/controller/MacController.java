package com.capgemini.uas.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ParticipantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IMacService;


@Controller
public class MacController {

	@Autowired
	private IMacService macService;

	ParticipantBean participant=null;
	Logger logger=Logger.getLogger(MacController.class);
	@RequestMapping("/macLogin")
	public String macLogin(Model model) {
		model.addAttribute("userObj", new UsersBean());
		return "jsp/login";

	}

	@RequestMapping("/validateLogin")
	public String validateLogin(@ModelAttribute("userObj") @Valid UsersBean user,BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "jsp/login";
		}
		try {
			UsersBean userInfo = macService.isValidUserLogin(user);
			if (userInfo != null) {
				if (userInfo.getRole().equalsIgnoreCase("mac")) {
					logger.info("In mac");
					return "jsp/macView";
				} else if (userInfo.getRole().equalsIgnoreCase("admin")) {
					return "jsp/AdminHome";
				}
			} else {
				return "jsp/login";
			}
		} catch (UASException exception) {
			logger.info("error occured");
			String errObj = exception.getMessage();
			model.addAttribute("errObj", errObj);
			return "jsp/dataerror";
		}
		return "jsp/login";

	}
	@RequestMapping("/updateAfterInterview")
	public String updateAfterInterview(Model model){
		List<ApplicantBean> applicantList=macService.getAcceptedApplicant();
		model.addAttribute("acceptedList",applicantList);
		return "jsp/afterinterview";
	}
	
	
	@RequestMapping("/confirmApplicant")
	public String confirmApplicant(@RequestParam("appId")int appId,@RequestParam("email")String emailId,@RequestParam("programId")String scheduleProgId,Model model){
		boolean isConfirm=macService.confirmApplicant(appId);
		boolean inserted=false;
		if(isConfirm){
			inserted=macService.addParticipant(appId,emailId,scheduleProgId);
			if(inserted){
				return "jsp/confirmApplicant";
			}
			return "jsp/confirmAppbutnotpart";
		}else{
			return "jsp/notUpdated";
		}		
	}
	
	@RequestMapping("/rejectApplicant")
	public String rejectApplicant(@RequestParam("appId")int appId,Model model){
		boolean isRejected=macService.rejectApplicant(appId);
		if(isRejected){
			return "jsp/rejectApplicant";
		}else{
			return "jsp/notUpdated";
		}
	}
	

	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception e) {
		// send email to control center
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", e);
		mav.setViewName("jsp/dataerror");
		System.out.println(e.getMessage());
		return mav;
	}
}
