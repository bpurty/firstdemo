package com.capgemini.uas.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Participant")
public class ParticipantBean {

	// Variable Declaration
	@Id
	@SequenceGenerator(name = "participantSeq", sequenceName = "Participant_seq", initialValue = 1230, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "participantSeq")
	@Column(name="Roll_no")
	private String rollNo;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="application_id")
	private int appId;
	
	@Column(name="Scheduled_program_id")
	private String scheduleProgId;

	// Parameterized Constructor
	public ParticipantBean(String rollNo, String emailId, int appId,
			String scheduleProgId) {

		this.rollNo = rollNo;
		this.emailId = emailId;
		this.appId = appId;
		this.scheduleProgId = scheduleProgId;
	}

	public ParticipantBean() {
		// Default Constructor
	}

	// Getters and Setters Methods
	
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}

	
	public String getScheduleProgId() {
		return scheduleProgId;
	}
	public void setScheduleProgId(String scheduleProgId) {
		this.scheduleProgId = scheduleProgId;
	}

	// toString() Method Overriden
	@Override
	public String toString() {
		return "Participant [rollNo=" + rollNo + ", emailId=" + emailId
				+ ", appId=" + appId + ", scheduleProgId=" + scheduleProgId
				+ "]";
	}

}
