package com.capgemini.uas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Programs_Offered")
public class ProgramOfferedBean {
	
	//Variable Declaration
	@Id
	@Column(name="ProgramName")
	private String progName;
	
	@Column(name="description")
	private String desc;
	
	@Column(name="applicant_eligibility")
	private String appEligibility;
	
	@Column(name="duration")
	private int duration;
	
	@Column(name="degree_certificate_offered")
	private String degreeOffered;
	
	
	//Getters and Setters Methods
	
	public String getProgName() {
		return progName;
	}
	public void setProgName(String progName) {
		this.progName = progName;
	}
	
	
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
	public String getAppEligibility() {
		return appEligibility;
	}
	public void setAppEligibility(String appEligibility) {
		this.appEligibility = appEligibility;
	}
	
	
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	
	public String getDegreeOffered() {
		return degreeOffered;
	}
	public void setDegreeOffered(String degreeOffered) {
		this.degreeOffered = degreeOffered;
	}
	
	//toString() Method Overriden
	@Override
	public String toString() {
		return "Program Offered\nName = " + progName + "\nDescription = " + desc
				+ "\nEligibility Criteria = " + appEligibility + "\nDuration = "
				+ duration + "\nDegree Offered = " + degreeOffered + "]";
	}
	
	
	// Parameterized Constructor
	public ProgramOfferedBean(String progName, String desc, String appEligibility,
			int duration, String degreeOffered) {

		this.progName = progName;
		this.desc = desc;
		this.appEligibility = appEligibility;
		this.duration = duration;
		this.degreeOffered = degreeOffered;
	}
	
	// Default Constructor
	public ProgramOfferedBean() {
		
	}
}
