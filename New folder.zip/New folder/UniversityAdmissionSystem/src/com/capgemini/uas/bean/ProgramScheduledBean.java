package com.capgemini.uas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.sql.Date;

@Entity
@Table(name = "Programs_Scheduled")
public class ProgramScheduledBean {

	// Variable Declaration
	@Id
	@Column(name = "Scheduled_program_id")
	private String scheduleProgId;
	@Column(name = "ProgramName")
	private String progName;
	@Column(name = "Location")
	private String location;
	@Column(name = "start_date")
	private Date start;
	@Column(name = "end_date ")
	private Date end;
	@Column(name = "session_per_week")
	private int session;

	// Getters and Setters Methods

	public String getScheduleProgId() {
		return scheduleProgId;
	}

	public void setScheduleProgId(String scheduleProgId) {
		this.scheduleProgId = scheduleProgId;
	}

	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getStart() {
		return start;
	}

	public void setStart(Date start) {
		this.start = start;
	}

	public Date getEnd() {
		return end;
	}

	public void setEnd(Date end) {
		this.end = end;
	}

	public int getSession() {
		return session;
	}

	public void setSession(int session) {
		this.session = session;
	}

	// toString() Method Overriden
	@Override
	public String toString() {
		return "Program Scheduled\nScheduled Progam Id = " + scheduleProgId
				+ "\n Program Name = " + progName + "\nLocation = " + location
				+ "\nStart Date = " + start + "\nEnd Date = " + end
				+ "\nSession = " + session + "]";
	}

	// Parameterized Constructor
	public ProgramScheduledBean(String scheduleProgId, String progName,
			String location, Date start, Date end, int session) {

		this.scheduleProgId = scheduleProgId;
		this.progName = progName;
		this.location = location;
		this.start = start;
		this.end = end;
		this.session = session;
	}

	// Default Constructor
	public ProgramScheduledBean() {

	}
}
