package com.capgemini.uas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.dao.IMacDao;
import com.capgemini.uas.exception.UASException;
@Transactional
@Service("macService")
public class MacServiceImpl implements IMacService {

	@Autowired
	private IMacDao macDao;

	@Override
	public UsersBean isValidUserLogin(UsersBean user) throws UASException {
		return macDao.isValidUserLogin(user);
	}

	@Override
	public List<ApplicantBean> getAcceptedApplicant() {
		return macDao.getAcceptedApplicant();
	}

	@Override
	public boolean confirmApplicant(int appId) {
		return macDao.confirmApplicant(appId);
	}

	@Override
	public boolean rejectApplicant(int appId) {
		return macDao.rejectApplicant(appId);
	}

	@Override
	public boolean addParticipant(int appId, String emailId,
			String scheduleProgId) {
		return macDao.addParticipant(appId,emailId,scheduleProgId);
	}
	

}
