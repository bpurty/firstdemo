package com.capgemini.uas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.uas.exception.UASException;

//@Service("adminServ")
public class AdminServiceImpl implements IAdminService {

	//@Autowired
	//

}
