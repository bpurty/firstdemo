package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;

public interface IApplicantService {
	List<ProgramScheduledBean> getAllPrograms() throws UASException;
	String getStatusbyId(int appId) throws UASException;
}
