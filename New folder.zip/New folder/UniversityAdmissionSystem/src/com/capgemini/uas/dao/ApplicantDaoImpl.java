package com.capgemini.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;


@Transactional
@Repository
public class ApplicantDaoImpl implements IApplicantDao {
	
	@PersistenceContext
	private EntityManager eManager;

	
	@Override
	public List<ProgramScheduledBean> getAllPrograms() throws UASException {
		System.out.println("Dao impl to get all programs");
		String selectAllQuery = "SELECT programs FROM ProgramScheduledBean programs";
		TypedQuery<ProgramScheduledBean> query = eManager.createQuery(selectAllQuery, ProgramScheduledBean.class);
		List<ProgramScheduledBean> programList = query.getResultList();
		System.out.println("Fetching program objects from DB (DAO)....");
		return programList;
	}

	@Override
	public String getStatusbyId(int appId) throws UASException{
		// TODO Auto-generated method stub
		return null;
	}
	
	
	/*@Override
	public boolean saveBooking(BookingDetails bookingdetails) {
		boolean success = false;
		System.out.println("Entered Dao for saving");
		try {
			eManager.persist(bookingdetails);
			success = true;
		} catch (Exception e) {
			// log error
			e.printStackTrace(); // remove this
		}
		return success;
	}
	
	@Override
	public HotelDetails getHotelbyId(int id) {
		System.out.println("Dao impl to get hotel name called mm");
		HotelDetails hotel =eManager.find(HotelDetails.class, id);
		return hotel;
	}
*/
}
