package com.capgemini.uas.dao;

import com.capgemini.uas.exception.UASException;

public interface IAdminDao {

}
