package com.capgemini.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.RollbackException;
import javax.transaction.Transactional;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ParticipantBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;

@Repository
@Transactional
public class MacDaoImpl implements IMacDao {
	@PersistenceContext
	EntityManager entityManager;
	ApplicantBean applicant = null;
	Logger logger = Logger.getLogger(MacDaoImpl.class);

	@Override
	public UsersBean isValidUserLogin(UsersBean userDetails)
			throws UASException {
		UsersBean user;
		try {
			user = entityManager
					.find(UsersBean.class, userDetails.getLoginId());
		} catch (Exception exception) {
			// logger.info(e.getMessage());
			throw new UASException(exception.getMessage());
		} finally {
			if (entityManager != null) {
				// logger.info("entity manager is closeds");
				entityManager.close();
			}
		}
		if (user != null
				&& userDetails.getPassword().equals(user.getPassword()))
			return user;
		else {
			// logger.info("Username or password does not match");
			throw new UASException("Username or password does not match");
		}
	}

	@Override
	public List<ApplicantBean> getAcceptedApplicant() {

		String qry = "SELECT applicant FROM ApplicantBean applicant where applicant.status='ACCEPTED'";
		TypedQuery<ApplicantBean> query = entityManager.createQuery(qry,
				ApplicantBean.class);
		List<ApplicantBean> aList = query.getResultList();
		return aList;
	}

	@Override
	public boolean confirmApplicant(int applicantId) {
		boolean confirmDone = false;
		int isConfirm = 0;
		String updateQuery = "UPDATE ApplicantBean applicant SET applicant.status='CONFIRMED' where applicant.appId=:applicantId";
		Query query = entityManager.createQuery(updateQuery);
		query.setParameter("applicantId", applicantId);
		isConfirm = query.executeUpdate();
		if (isConfirm > 0) {
			confirmDone = true;
			return confirmDone;
		} else {
			return confirmDone;
		}
	}

	@Override
	public boolean rejectApplicant(int applicantId) {
		boolean rejectDone = false;
		int isRejected = 0;
		String updateQuery = "UPDATE ApplicantBean applicant SET applicant.status='REJECTED' where applicant.appId=:applicantId";
		Query query = entityManager.createQuery(updateQuery);
		query.setParameter("applicantId", applicantId);
		isRejected = query.executeUpdate();
		if (isRejected > 0) {
			rejectDone = true;
			return rejectDone;
		} else {
			return rejectDone;
		}
	}

	@Override
	public boolean addParticipant(int appId, String emailId,String scheduleProgId) {
		boolean success=false;
		ParticipantBean participant=new ParticipantBean();
		
		participant.setAppId(appId);
		participant.setEmailId(emailId);
		participant.setScheduleProgId(scheduleProgId);
		System.out.println("in persist");
         entityManager.persist(participant);
         success=true;
		return success;
	}
}
