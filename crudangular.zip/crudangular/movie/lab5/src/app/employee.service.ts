import { Injectable }      from '@angular/core';
import {Employee} from './employee';
import {Movies} from './movie';
import {Http,Response,Headers, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"
//import "rxjs/add/operator/throw"
@Injectable()
export class MovieService{
   
    constructor(private http:Http) {}
  //For All Application check your your REST URI-PORT & Path   
    //GET ALL -with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee
    getAllMovies():Observable<Movies[]> 
{ return  this.http.get("http://localhost:8081/MySpringRestDemo/rest/movies").
        map((response:Response)=><Movies[]>response.json())
        .catch(this.handleError);
    }
    handleError(error: Response){
        console.error(error);
        return Observable.throw(error);
    }
    
    
    //delete data--with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee/delete/
    deleteMovieId(data:number): Observable<Movies[]> {
        console.log(data)
        return this.http
            .delete('http://localhost:8081/MySpringRestDemo/rest/movies/delete/'+data)
            .map((response:Response)=><Movies[]>response.json())
            .catch(this.handleError);
        }
        handleErrorDelete(error: Response){
            console.error(error);
            return Observable.throw(error);
        }
        //add data--with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee/create/
        addMovie(data:Movies): Observable<Movies[]> {
            let movData=JSON.stringify(data);
            alert(movData);
            let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
            let options = new RequestOptions({ headers: cpHeaders });
            
            return this.http
                .post('http://localhost:8081/MySpringRestDemo/rest/movies/create/',movData,options)
                .map((success => success.status))
                .catch(this.handleError);
            }
            handleErrorAdd(error: Response){
                console.error(error);
                return Observable.throw(error);
            }
            //search data--with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee/search/
            searchMovieId(data:number): Observable<Movies[]> {
                
                return this.http
                    .get('http://localhost:8081/MySpringRestDemo/rest/movies/search/'+data)
                    .map((response:Response)=><Movies[]>response.json())
                    .catch(this.handleError);
                }
                handleErrorSearch(error: Response){
                    console.error(error);
                    return Observable.throw(error);
                }
                //update Data --with Spring JPA-http://localhost:9090/SpringWithJpa/rest/employee/update/
                updateMovie(data:Movies): Observable<Movies[]> {
                    let movData=JSON.stringify(data);
                    alert(movData);
                    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
                    let options = new RequestOptions({ headers: cpHeaders });
                    
                    return this.http
                        .put('http://localhost:8081/MySpringRestDemo/rest/movies/update/',movData,options)
                        .map((success => success.status))
                        .catch(this.handleError);
                        
                    }
                    handleErrorupdate(error: Response){
                        console.error(error);
                        return Observable.throw(error);
                    }
    }
