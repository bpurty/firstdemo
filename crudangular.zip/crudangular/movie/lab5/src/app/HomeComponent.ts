
import { Component, OnInit } from '@angular/core';
import {Movies} from './movie'
import { MovieService } from "./employee.service";
import {Router} from '@angular/router'
@Component({
  selector: 'my-app',
  templateUrl:'./homecomponent.html',
      providers:[MovieService]
})
export class HomeComponent {
   
    movies:Movies[];
statusmessage:string;
constructor(private empservice:MovieService,private router:Router) {}
    
    
    model:any={};

addData():void{
    this.empservice.addMovie(this.model).subscribe((data)=>this.movies=data,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    //Navigate from HomeComponent to EmployeeList
    //this.router.navigate(['/getdata']);
    this.router.navigate(['/getdata',{term:this.movies}]);
}
    
}
