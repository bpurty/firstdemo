import {  Pipe, PipeTransform }      from '@angular/core';
import { IFlight } from "./flight";

@Pipe({
  name: 'searchPipe'
  
})
export class SearchPipe implements PipeTransform {
    transform(flights: any, search: any, index: number): any {
       if(search == null || search == undefined) return flights;
       return flights.filter(function(flight :any) {
           console.log(flight);
           let val: any;
           switch(index) {
               case 1: val = flight.id.toString().includes(search); break;
               case 2: val = flight.name.toLowerCase().includes(search.toLowerCase()); break;
               case 3: val = flight.departure.toLowerCase().includes(search); break;
               case 4: val = flight.arrival.toString().includes(search); break;
               case 5: val = flight.status.toString().includes(search); break;
               case 6: val = flight.cost.toString().includes(search); break;
               default: console.log("Something is wrong");
           }
           return val;
       })
    }
    
}
